package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Student;
import org.springframework.stereotype.Repository;

@Repository("studentDao")
@Transactional
public class StudentDaoImpl implements StudentDao {
	@PersistenceContext
	private EntityManager em; 
		
			public List<Student> getStudent() {
			List<Student> students = em.createQuery("from Student").getResultList();
			return students;
			}
			@Override
			public Student findStudent(Integer stuId) {
				// TODO Auto-generated method stub
					Student student= em.find(Student.class, stuId);
					return student;
			} 
			@Override
			public void update(Student student) {
				// TODO Auto-generated method stub
				if(student.getStuId()!=0)
					em.merge(student);
				else
					em.persist(student);
				
			}
		
	
}
