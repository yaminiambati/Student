package org.cap.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Student {
	@Id
	private int stuId;
	private String stuName;
	private String stuLoc;
	public int getStuId() {
		return stuId;
	}
	public void setStuId(int stuId) {
		this.stuId = stuId;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public String getStuLoc() {
		return stuLoc;
	}
	public void setStuLoc(String stuLoc) {
		this.stuLoc = stuLoc;
	}
	@Override
	public String toString() {
		return "Student [stuId=" + stuId + ", stuName=" + stuName + ", stuLoc=" + stuLoc + "]";
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int stuId, String stuName, String stuLoc) {
		super();
		this.stuId = stuId;
		this.stuName = stuName;
		this.stuLoc = stuLoc;
	}
	

}
