package org.cap.service;

import java.util.List;

import org.cap.dao.StudentDao;
import org.cap.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("studentService")
public class StudentServiceImpl implements StudentService {
	@Autowired
	private StudentDao studentDao;

	@Override
	public List<Student> getStudent() {
		// TODO Auto-generated method stub
		return studentDao.getStudent();
	}
	@Override
	public Student findStudent(Integer stuId) {
		
		return studentDao.findStudent(stuId);
	}
	@Override
	public void update(Student student) {
		// TODO Auto-generated method stub
		studentDao.update(student);
		
	}

}
